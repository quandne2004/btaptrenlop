package examine1.examine1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Examine1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
